async function CrearDocumento(coleccion, documento) {
    try {
        const db = await conectar();
        const resultado = await db.collection(coleccion).insertOne(documento);
        console.log("Documento creado:", resultado.insertedId);
    } catch (error) {
        console.error("Error al crear el documento:", error);
    }
}
