async function ObservarElNewDocument(coleccion) {
    try {
      const db = await conectar();
      const documentos = await db.collection(coleccion).find().toArray();
      console.log('Documentos:', documentos);
    } catch (error) {
      console.error('Error al leer los documentos:', error);
    }
  }