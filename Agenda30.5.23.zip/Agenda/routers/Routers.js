const CrearDocumento = require("../controllers/NewDocument.js");
const LeerDocumento = require("../controllers/read.js")
const EliminalDocumento = require("../controllers/deleteDocument.js")
const express = require("express");
const router = express.Router();

//Defino rutas y acciones de respuesta
router.route("/").get(NewDocument.inicio);

router.rotur("/").get()

router.rotur("/").get()

module.exports = router;
